#include "triangle.h"

triangle::triangle()
{

}
