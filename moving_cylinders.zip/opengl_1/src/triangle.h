#ifndef TRIANGLE_H
#define TRIANGLE_H


class triangle
{
public:
    triangle();
};

#endif // TRIANGLE_H
